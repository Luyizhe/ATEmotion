import sys
import ATEmotion
import ATEmotion.CN_Emotion
import ATEmotion.extract_feature
import ATEmotion.LoadData
import ATEmotion.model
import ATEmotion.train_test